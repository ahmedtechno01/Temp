Projet Flutter de base pour l'application Zembra.
Contient le point d'entrée principal et une structure initiale.