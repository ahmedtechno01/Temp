
import 'package:flutter/material.dart';

void main() {
  runApp(ZembraApp());
}

class ZembraApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Zembra',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      home: Scaffold(
        appBar: AppBar(title: Text('Zembra - Accueil')),
        body: Center(child: Text('Bienvenue à Zembra!')),
      ),
    );
  }
}
